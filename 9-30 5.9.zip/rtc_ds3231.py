def format_history_time(value):
    """Keep legacy time-only records readable without inventing a date."""
    value = str(value or "")
    if (len(value) >= 16 and value[4] == "-" and value[7] == "-"
            and value[10] == " " and value[13] == ":"):
        return value[:16]
    if len(value) >= 5 and value[2] == ":":
        return "----/--/-- " + value[:5]
    return "----/--/-- --:--"


class DS3231:
    """Unified DS3231/PCF8563 RTC driver.

    The class name is kept for compatibility with the existing application.
    """

    DS3231_ADDR = 0x68
    PCF8563_ADDR = 0x51

    def __init__(self, i2c, addr=None):
        self.i2c = i2c
        self.addr = addr
        self.model = "UNKNOWN"
        self.detect()

    def _dec2bcd(self, dec):
        return ((dec // 10) << 4) | (dec % 10)

    def _bcd2dec(self, bcd):
        return ((bcd >> 4) * 10) + (bcd & 0x0F)

    def _decode_bcd(self, raw, mask, minimum, maximum):
        value = raw & mask
        if (value & 0x0F) > 9 or ((value >> 4) & 0x0F) > 9:
            return None
        value = self._bcd2dec(value)
        if not minimum <= value <= maximum:
            return None
        return value

    def _probe(self, addr, reg):
        try:
            self.i2c.readfrom_mem(addr, reg, 1)
            return True
        except:
            return False

    def detect(self):
        if self.addr == self.DS3231_ADDR:
            candidates = ((self.DS3231_ADDR, "DS3231", 0x00),)
        elif self.addr == self.PCF8563_ADDR:
            candidates = ((self.PCF8563_ADDR, "PCF8563", 0x02),)
        else:
            candidates = (
                (self.DS3231_ADDR, "DS3231", 0x00),
                (self.PCF8563_ADDR, "PCF8563", 0x02),
            )

        try:
            devices = self.i2c.scan()
        except:
            devices = None

        for addr, model, reg in candidates:
            if devices is not None and addr not in devices:
                continue
            if self._probe(addr, reg):
                self.addr = addr
                self.model = model
                return model

        self.addr = None
        self.model = "UNKNOWN"
        return self.model

    def get_model(self):
        return self.model

    def is_present(self):
        return self.addr is not None and self.model != "UNKNOWN"

    def get_time(self):
        """Return (hour, minute, second)."""
        try:
            if self.model == "DS3231":
                data = self.i2c.readfrom_mem(self.addr, 0x00, 3)
                second = self._bcd2dec(data[0] & 0x7F)
                minute = self._bcd2dec(data[1] & 0x7F)
                hour_reg = data[2]
                if hour_reg & 0x40:
                    hour = self._bcd2dec(hour_reg & 0x1F)
                    if hour_reg & 0x20:
                        hour = (hour % 12) + 12
                    elif hour == 12:
                        hour = 0
                else:
                    hour = self._bcd2dec(hour_reg & 0x3F)
                return (hour, minute, second)

            if self.model == "PCF8563":
                data = self.i2c.readfrom_mem(self.addr, 0x02, 3)
                second = self._decode_bcd(data[0], 0x7F, 0, 59)
                minute = self._decode_bcd(data[1], 0x7F, 0, 59)
                hour = self._decode_bcd(data[2], 0x3F, 0, 23)
                if second is None or minute is None or hour is None:
                    return (0, 0, 0)
                return (hour, minute, second)
        except:
            pass
        return (0, 0, 0)

    def get_time_str(self, show_seconds=False):
        """Return HH:MM or HH:MM:SS."""
        hour, minute, second = self.get_time()
        if show_seconds:
            return f"{hour:02}:{minute:02}:{second:02}"
        return f"{hour:02}:{minute:02}"

    def get_history_time_str(self):
        """Read one RTC snapshot so the date and minute agree at midnight."""
        try:
            if self.model not in ("DS3231", "PCF8563"):
                return format_history_time(None)
            is_ds = self.model == "DS3231"
            data = self.i2c.readfrom_mem(self.addr, 0x00 if is_ds else 0x02, 7)
            minute = self._decode_bcd(data[1], 0x7F, 0, 59)
            if is_ds and data[2] & 0x40:
                hour = self._decode_bcd(data[2], 0x1F, 1, 12)
                if hour is not None:
                    hour = hour % 12 + (12 if data[2] & 0x20 else 0)
            else:
                hour = self._decode_bcd(data[2], 0x3F, 0, 23)
            day = self._decode_bcd(data[4 if is_ds else 3], 0x3F, 1, 31)
            month = self._decode_bcd(data[5], 0x1F, 1, 12)
            year = self._decode_bcd(data[6], 0xFF, 0, 99)
            if None in (hour, minute, day, month, year):
                return format_history_time(None)
            return f"20{year:02}-{month:02}-{day:02} {hour:02}:{minute:02}"
        except Exception:
            return format_history_time(None)

    def get_date(self):
        """Return (year, month, day), where year is the two-digit 20xx year."""
        try:
            if self.model == "DS3231":
                data = self.i2c.readfrom_mem(self.addr, 0x04, 3)
                day = self._bcd2dec(data[0] & 0x3F)
                month = self._bcd2dec(data[1] & 0x1F)
                year = self._bcd2dec(data[2])
                return (year, month, day)

            if self.model == "PCF8563":
                data = self.i2c.readfrom_mem(self.addr, 0x05, 4)
                day = self._decode_bcd(data[0], 0x3F, 1, 31)
                month = self._decode_bcd(data[2], 0x1F, 1, 12)
                year = self._decode_bcd(data[3], 0xFF, 0, 99)
                if day is None or month is None or year is None:
                    return (0, 0, 0)
                return (year, month, day)
        except:
            pass
        return (0, 0, 0)

    def needs_sync(self):
        if not self.is_present():
            return True

        try:
            year, month, day = self.get_date()
            date_invalid = (
                year < 24
                or not 1 <= month <= 12
                or not 1 <= day <= 31
            )

            if self.model == "DS3231":
                if date_invalid:
                    return True

                # OSF is sticky and is also set on first power-up. A valid
                # stored date is sufficient here; clear the historical flag
                # so it does not force date setup on every subsequent boot.
                self._clear_ds3231_osf()
                return False

            if self.model == "PCF8563":
                voltage_low = bool(
                    self.i2c.readfrom_mem(self.addr, 0x02, 1)[0] & 0x80
                )
                return voltage_low or date_invalid
        except:
            return True

        return True

    def _clear_ds3231_osf(self):
        if self.model != "DS3231":
            return
        try:
            status = self.i2c.readfrom_mem(self.addr, 0x0F, 1)[0]
            self.i2c.writeto_mem(self.addr, 0x0F, bytes([status & 0x7F]))
        except:
            pass

    def _clear_pcf8563_vl(self):
        if self.model != "PCF8563":
            return
        try:
            second = self.i2c.readfrom_mem(self.addr, 0x02, 1)[0] & 0x7F
            self.i2c.writeto_mem(self.addr, 0x02, bytes([second]))
        except:
            pass

    def _start_pcf8563(self):
        if self.model != "PCF8563":
            return
        try:
            control = self.i2c.readfrom_mem(self.addr, 0x00, 1)[0]
            self.i2c.writeto_mem(self.addr, 0x00, bytes([control & 0xDF]))
        except:
            pass

    def sync_time(self, hh, mm):
        """Set hour/minute and reset seconds to zero."""
        if not 0 <= hh <= 23 or not 0 <= mm <= 59:
            return False

        try:
            data = bytes([0, self._dec2bcd(mm), self._dec2bcd(hh)])
            if self.model == "DS3231":
                self.i2c.writeto_mem(self.addr, 0x00, data)
                self._clear_ds3231_osf()
                return True

            if self.model == "PCF8563":
                self._start_pcf8563()
                self.i2c.writeto_mem(self.addr, 0x02, data)
                return True
        except:
            pass
        return False

    def set_date(self, yy, mm, dd):
        """Set date, where yy is the last two digits of a 20xx year."""
        if not 0 <= yy <= 99 or not 1 <= mm <= 12 or not 1 <= dd <= 31:
            return False

        try:
            if self.model == "DS3231":
                data = bytes([
                    self._dec2bcd(dd),
                    self._dec2bcd(mm),
                    self._dec2bcd(yy),
                ])
                self.i2c.writeto_mem(self.addr, 0x04, data)
                self._clear_ds3231_osf()
                return True

            if self.model == "PCF8563":
                self._start_pcf8563()
                self.i2c.writeto_mem(
                    self.addr,
                    0x05,
                    bytes([
                        self._dec2bcd(dd),
                        0,
                        self._dec2bcd(mm),
                        self._dec2bcd(yy),
                    ]),
                )
                self._clear_pcf8563_vl()
                return True
        except:
            pass
        return False
