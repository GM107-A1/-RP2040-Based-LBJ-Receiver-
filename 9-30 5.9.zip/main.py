import time
import json
import machine
import os
import gc
import sdcard
import _thread
import array
from machine import Pin, ADC, I2C
from lbj_receiver import LBJReceiver, FixedQueue
from ili9341 import ILI9341, BLACK, WHITE, RED, GREEN, BLUE, CYAN, YELLOW, GRAY, MAGENTA
from rtc_ds3231 import DS3231, format_history_time
from boot_post import SystemPOST

# 系统性能配置
CPU_FREQ_HZ = 200000000
TFT_SPI_BAUD = 60000000
UI_QUEUE_CAPACITY = 16
HISTORY_QUEUE_CAPACITY = 24
HISTORY_RADIO_QUIET_MS = 100
STORAGE_WRITE_GAP_MS = 80
RADIO_CORE_STALL_MS = 10000
RADIO_ERROR_RECOVERY_THRESHOLD = 3
RADIO_AUTO_RECOVERY_ENABLED = True
RADIO_HEALTH_LOG_MS = 60000
BUTTON_BEEP_MS = 25

pin_bl = Pin(6, Pin.OUT, value=0)
machine.freq(CPU_FREQ_HZ)
try:
    print("BOOT_RESET_CAUSE", machine.reset_cause())
except Exception:
    pass

Program_ver = 5.9
is_es_ver = 0
Author_Name = "AS-GM107"
BAT_OFFSET = 0.174

ui_queue = FixedQueue(UI_QUEUE_CAPACITY)
history_queue = FixedQueue(HISTORY_QUEUE_CAPACITY)
sd_log_queue = FixedQueue(HISTORY_QUEUE_CAPACITY)
ui_lock = _thread.allocate_lock()
RADIO_HEARTBEAT = 0
RADIO_CONSECUTIVE_ERRORS = 1
RADIO_TOTAL_ERRORS = 2
RADIO_LAST_ERROR_LOG = 3
radio_state = [time.ticks_ms(), 0, 0, 0]
last_radio_health_log = 0
last_storage_write = 0

last_hw_update = 0
last_rssi_str = "N/A"
hist_rssi_str = "N/A"
screen_is_on = True
last_battery_v = None
last_battery_p = None
last_temp_str = None
last_vbus_display = None

# 1. 硬件 IO 初始化
tft_cs = Pin(9, Pin.OUT, value=1)
spi1 = machine.SPI(1, baudrate=20000000, sck=Pin(10), mosi=Pin(11), miso=Pin(8, Pin.IN, Pin.PULL_UP))
tft = ILI9341(spi1, cs=9, dc=12, rst=13)
spi1.init(baudrate=TFT_SPI_BAUD, polarity=0, phase=0)

sd_cs = Pin(7, Pin.OUT, value=1)
bat_en = Pin(14, Pin.OUT, value=1)
bat_adc = ADC(Pin(27))
vbus_sense = Pin(24, Pin.IN)
buzzer = Pin(22, Pin.OUT, value=0)

i2c0 = I2C(0, sda=Pin(0), scl=Pin(1), freq=400000)
rtc = DS3231(i2c0)

btn_menu, btn_up, btn_down, btn_ok = [Pin(i, Pin.IN, Pin.PULL_UP) for i in (2, 3, 4, 5)]
btn_wake = Pin(28, Pin.IN, Pin.PULL_UP)
sensor_temp = machine.ADC(4)


class ButtonTracker:
    def __init__(self, pin, repeat=False, debounce_ms=12,
                 repeat_delay_ms=350, repeat_interval_ms=120):
        self.pin = pin
        self.repeat = repeat
        self.debounce_ms = debounce_ms
        self.repeat_delay_ms = repeat_delay_ms
        self.repeat_interval_ms = repeat_interval_ms
        self.raw_pressed = not pin.value()
        self.stable_pressed = self.raw_pressed
        self.changed_at = time.ticks_ms()
        self.repeat_at = time.ticks_add(self.changed_at, repeat_delay_ms)

    def poll(self, now):
        raw_pressed = not self.pin.value()
        if raw_pressed != self.raw_pressed:
            self.raw_pressed = raw_pressed
            self.changed_at = now

        if (
            self.raw_pressed != self.stable_pressed
            and time.ticks_diff(now, self.changed_at) >= self.debounce_ms
        ):
            self.stable_pressed = self.raw_pressed
            if self.stable_pressed:
                self.repeat_at = time.ticks_add(now, self.repeat_delay_ms)
                return True
            return False

        if (
            self.repeat
            and self.raw_pressed
            and self.stable_pressed
            and time.ticks_diff(now, self.repeat_at) >= 0
        ):
            self.repeat_at = time.ticks_add(now, self.repeat_interval_ms)
            return True
        return False


def safe_fill_rect(x, y, w, h, color):
    tft.fill_rect(x, y, w, h, color)


LOCO_NAME_GBK = {
    "解放": b"\xbd\xe2\xb7\xc5",
    "前进": b"\xc7\xb0\xbd\xf8",
    "建设": b"\xbd\xa8\xc9\xe8",
    "蓝箭控车": b"\xc0\xb6\xbc\xfd\xbf\xd8\xb3\xb5",
    "北京": b"\xb1\xb1\xbe\xa9",
    "北京宽": b"\xb1\xb1\xbe\xa9\xbf\xed",
    "轻油": b"\xc7\xe1\xd3\xcd",
    "天安": b"\xcc\xec\xb0\xb2",
    "新曙光": b"\xd0\xc2\xca\xef\xb9\xe2",
    "神州": b"\xc9\xf1\xd6\xdd",
    "DJ熊猫": b"DJ\xd0\xdc\xc3\xa8",
    "蓝箭动车": b"\xc0\xb6\xbc\xfd\xb6\xaf\xb3\xb5",
    "先锋号": b"\xcf\xc8\xb7\xe6\xba\xc5",
    "天梭": b"\xcc\xec\xcb\xf3",
    "DJ4和谐": b"DJ4\xba\xcd\xd0\xb3",
    "轨道探伤车": b"\xb9\xec\xb5\xc0\xcc\xbd\xc9\xcb\xb3\xb5",
    "起重轨道车": b"\xc6\xf0\xd6\xd8\xb9\xec\xb5\xc0\xb3\xb5",
    "轨道打磨车": b"\xb9\xec\xb5\xc0\xb4\xf2\xc4\xa5\xb3\xb5",
    "动力稳定车": b"\xb6\xaf\xc1\xa6\xce\xc8\xb6\xa8\xb3\xb5",
    "雪域神舟": b"\xd1\xa9\xd3\xf2\xc9\xf1\xd6\xdb",
}
UNKNOWN_LOCO_GBK = b"\xce\xb4\xd6\xaa"

# ===== 旅客列车规则 =====
TRAIN_TYPE_RULES = [
    (1001, 3998, b"\xd6\xb1\xcd\xa8\xc2\xc3\xbf\xcd\xc6\xd5\xbf\xec", GREEN),
    (4001, 5998, b"\xb9\xdc\xc4\xda\xc2\xc3\xbf\xcd\xc6\xd5\xbf\xec", GREEN),
    (6001, 6198, b"\xd6\xb1\xcd\xa8\xc2\xc3\xbf\xcd\xc2\xfd\xb3\xb5", WHITE),
    (6201, 7598, b"\xb9\xdc\xc4\xda\xc2\xc3\xbf\xcd\xc2\xfd\xb3\xb5", WHITE),
    (7601, 8998, b"\xcd\xa8\xc7\xda\xc1\xd0\xb3\xb5", YELLOW),
]
# ===== 货运列车规则 =====
FREIGHT_TRAIN_RULES = [
    (10001, 19998, b"\xbc\xbc\xca\xf5\xd6\xb1\xb4\xef\xc1\xd0\xb3\xb5", WHITE),
    (20001, 29998, b"\xd6\xb1\xcd\xa8\xbb\xf5\xd4\xcb\xc1\xd0\xb3\xb5", WHITE),
    (30001, 39998, b"\xc7\xf8\xb6\xce\xbb\xf5\xd4\xcb\xc1\xd0\xb3\xb5", WHITE),
    (40001, 44998, b"\xd5\xaa\xb9\xd2\xc1\xd0\xb3\xb5", WHITE),
    (45001, 49998, b"\xd0\xa1\xd4\xcb\xd7\xaa\xc1\xd0\xb3\xb5", MAGENTA),
    (50001, 50998, b"\xbf\xcd\xb3\xb5\xb5\xa5\xbb\xfa", BLUE),
    (51001, 51998, b"\xbb\xf5\xb3\xb5\xb5\xa5\xbb\xfa", BLUE),
    (52001, 52998, b"\xd0\xa1\xd4\xcb\xd7\xaa\xb5\xa5\xbb\xfa", MAGENTA),
    (53001, 54998, b"\xb2\xb9\xbb\xfa", MAGENTA),
    (55001, 55998, b"\xca\xd4\xd4\xcb\xd0\xd0\xc1\xd0\xb3\xb5", MAGENTA),
    (56001, 56998, b"\xd0\xa1\xd0\xcd\xb9\xec\xb5\xc0\xb3\xb5", MAGENTA),
    (57001, 57998, b"\xc2\xb7\xd3\xc3\xc1\xd0\xb3\xb5", MAGENTA),
    (58101, 58998, b"\xbe\xc8\xd4\xae\xc1\xd0\xb3\xb5", RED),
    (60001, 69998, b"\xb9\xa4\xb3\xa7\xd7\xd4\xb1\xb8\xb3\xb5", WHITE),
    (70001, 70998, b"\xb3\xac\xcf\xde\xbb\xf5\xd4\xcb\xc1\xd0\xb3\xb5", YELLOW),
    (71001, 72998, b"\xcd\xf2\xb6\xd6\xbb\xf5\xd4\xcb\xc1\xd0\xb3\xb5", YELLOW),
    (73001, 74998, b"\xc0\xe4\xb2\xd8\xc1\xd0\xb3\xb5", YELLOW),
    (75001, 75998, b"\xbc\xaf\xd7\xb0\xcf\xe4\xd7\xa8\xc1\xd0", WHITE),
    (80001, 81748, b"\xd6\xb1\xb4\xef\xbb\xf5\xd4\xcb\xc1\xd0\xb3\xb5", WHITE),
    (81751, 81998, b"\xbf\xec\xd4\xcb\xbb\xf5\xd4\xcb\xc1\xd0\xb3\xb5", WHITE),
    (82001, 84998, b"\xc3\xba\xcc\xbf\xd6\xb1\xb4\xef\xc1\xd0\xb3\xb5", WHITE),
    (85001, 85998, b"\xca\xaf\xd3\xcd\xd6\xb1\xb4\xef\xc1\xd0\xb3\xb5", WHITE),
    (86001, 86998, b"\xca\xbc\xb7\xa2\xd6\xb1\xb4\xef\xc1\xd0\xb3\xb5", WHITE),
    (87001, 87998, b"\xbf\xd5\xb3\xb5\xd6\xb1\xb4\xef\xc1\xd0\xb3\xb5", WHITE),
    (88001, 88998, b"\xc6\xfb\xd4\xcb\xd7\xa8\xc1\xd0", WHITE),
    (89001, 89998, b"\xd4\xcb\xc1\xb8\xd7\xa8\xc1\xd0\xb3\xb5", WHITE),
    (90001, 92998, b"\xbe\xfc\xd3\xc3\xc1\xd0\xb3\xb5\xc2\xfa\xd4\xd8", RED),
    (93001, 94998, b"\xbe\xfc\xd3\xc3\xc1\xd0\xb3\xb5\xbf\xd5\xd4\xd8", RED),
    (95001, 97998, b"\xbe\xc8\xd4\xae\xc1\xd0\xb3\xb5", RED),
    (98001, 99998, b"\xcc\xd8\xd6\xd6\xc1\xd0\xb3\xb5", MAGENTA),
]


def get_train_type(train_no, class_tag=''):
    if class_tag == '00' and train_no and train_no != '---':
        tn = str(train_no).strip()
        if tn.isdigit():
            full_train = class_tag + tn
            num = int(full_train)
            if len(full_train) == 5:
                if 1 <= num <= 100:
                    return b"\xd3\xd0\xbb\xf0\xbb\xd8\xcb\xcd\xb6\xaf\xb3\xb5\xd7\xe9", RED
                elif 101 <= num <= 198:
                    return b"\xbf\xe7\xbe\xd6\xce\xde\xbb\xf0\xbb\xd8\xcb\xcd\xb6\xaf\xb3\xb5\xd7\xe9", RED
                elif 201 <= num <= 298:
                    return b"\xb9\xdc\xc4\xda\xce\xde\xbb\xf0\xbb\xd8\xcb\xcd\xb6\xaf\xb3\xb5\xd7\xe9", RED
                elif 301 <= num <= 398:
                    return b"\xbf\xe7\xbe\xd6\xbb\xd8\xcb\xcd\xbf\xcd\xb3\xb5", YELLOW
                elif 401 <= num <= 498:
                    return b"\xb9\xdc\xc4\xda\xbb\xd8\xcb\xcd\xbf\xcd\xb3\xb5", YELLOW

    F_TYPES = ['FK', 'FZ', 'FT', 'FD', 'FG', 'FY']
    if class_tag and class_tag in F_TYPES:
        try:
            num_part = int(''.join([c for c in str(train_no) if c.isdigit()]))
        except:
            num_part = 0
        if 1 <= num_part <= 9998:
            return b"\xd2\xf2\xb9\xca\xd6\xd0\xcd\xbe\xd5\xdb\xb7\xb5", YELLOW

    if train_no and train_no != '---':
        tn = str(train_no).strip()
        tn = tn.replace('\r', '').replace('\n', '')
        if len(tn) >= 2 and tn[:2] in F_TYPES:
            try:
                num_part = int(tn[2:])
            except:
                num_part = 0
            if 1 <= num_part <= 9998:
                return b"\xd2\xf2\xb9\xca\xd6\xd0\xcd\xbe\xd5\xdb\xb7\xb5", YELLOW

    if class_tag and class_tag == 'SY':
        try:
            num_part = int(''.join([c for c in str(train_no) if c.isdigit()]))
        except:
            num_part = 0
        if 1 <= num_part <= 9998:
            return b"\xca\xb5\xd1\xe9", YELLOW

    if train_no and train_no != '---':
        tn = str(train_no).strip()
        tn = tn.replace('\r', '').replace('\n', '')
        if len(tn) >= 2 and tn[:2] == 'SY':
            try:
                num_part = int(tn[2:])
            except:
                num_part = 0
            if 1 <= num_part <= 9998:
                return b"\xca\xb5\xd1\xe9", YELLOW

    if class_tag and class_tag == 'DJ':
        try:
            num_part = int(''.join([c for c in str(train_no) if c.isdigit()]))
        except:
            num_part = 0
        if 1 <= num_part <= 9998:
            return b"\xb6\xaf\xbc\xec", YELLOW

    if train_no and train_no != '---':
        tn = str(train_no).strip()
        tn = tn.replace('\r', '').replace('\n', '')
        if len(tn) >= 2 and tn[:2] == 'DJ':
            try:
                num_part = int(tn[2:])
            except:
                num_part = 0
            if 1 <= num_part <= 9998:
                return b"\xb6\xaf\xbc\xec", YELLOW

    if class_tag and len(class_tag) >= 2 and class_tag[0] == '0':
        letter = class_tag[1]
        if letter in 'GD':
            try:
                num_part = int(''.join([c for c in str(train_no) if c.isdigit()]))
            except:
                num_part = 0
            if 1 <= num_part <= 9998:
                return b"\xb6\xaf\xbc\xec/\xbb\xd8\xcb\xcd", YELLOW
        elif letter in 'KZTLYC':
            try:
                num_part = int(''.join([c for c in str(train_no) if c.isdigit()]))
            except:
                num_part = 0
            if 1 <= num_part <= 9998:
                return b"\xbf\xd5\xb3\xb5\xb5\xd7\xbb\xd8\xcb\xcd", YELLOW

    if train_no and train_no != '---':
        tn = str(train_no).strip()
        tn = tn.replace('\r', '').replace('\n', '')
        if len(tn) >= 2:
            first_two = tn[:2]
            if first_two in ['0G', '0D']:
                try:
                    num_part = int(tn[2:])
                except:
                    num_part = 0
                if 1 <= num_part <= 9998:
                    return b"\xb6\xaf\xbc\xec/\xbb\xd8\xcb\xcd", YELLOW
            elif first_two in ['0K', '0Z', '0T', '0Y', '0C']:
                try:
                    num_part = int(tn[2:])
                except:
                    num_part = 0
                if 1 <= num_part <= 9998:
                    return b"\xbf\xd5\xb3\xb5\xb5\xd7\xbb\xd8\xcb\xcd", YELLOW

    if class_tag and class_tag in 'KZTXLYGCDSJ':
        num_part = 0
        if train_no and train_no != '---':
            try:
                if train_no[0].isalpha():
                    num_part = int(train_no[1:])
                else:
                    num_part = int(train_no)
            except:
                num_part = 0

        if class_tag == 'Z':
            if 1 <= num_part <= 4998:
                return b"\xbf\xe7\xbe\xd6\xd6\xb1\xb4\xef\xcc\xd8\xbf\xec", RED
            elif 5001 <= num_part <= 9998:
                return b"\xb9\xdc\xc4\xda\xd6\xb1\xb4\xef\xcc\xd8\xbf\xec", RED
        elif class_tag == 'T':
            if 1 <= num_part <= 4998:
                return b"\xbf\xe7\xbe\xd6\xcc\xd8\xbf\xec", YELLOW
            elif 5001 <= num_part <= 9998:
                return b"\xb9\xdc\xc4\xda\xcc\xd8\xbf\xec", YELLOW
        elif class_tag == 'K':
            if 1 <= num_part <= 6998:
                return b"\xbf\xe7\xbe\xd6\xc6\xd5\xbf\xec", GREEN
            elif 7001 <= num_part <= 9998:
                return b"\xb9\xdc\xc4\xda\xc6\xd5\xbf\xec", GREEN
        elif class_tag == 'L':
            if 1 <= num_part <= 6998:
                return b"\xbf\xe7\xbe\xd6\xc1\xd9\xbf\xcd", CYAN
            elif 7001 <= num_part <= 9998:
                return b"\xb9\xdc\xc4\xda\xc1\xd9\xbf\xcd", CYAN
        elif class_tag == 'Y':
            if 1 <= num_part <= 498:
                return b"\xbf\xe7\xbe\xd6\xc2\xc3\xd3\xce", MAGENTA
            elif 501 <= num_part <= 998:
                return b"\xb9\xdc\xc4\xda\xc2\xc3\xd3\xce", MAGENTA
        elif class_tag == 'G':
            if 1 <= num_part <= 4998:
                return b"\xbf\xe7\xbe\xd6\xb8\xdf\xcb\xd9\xb6\xaf\xb3\xb5", GREEN
            elif 5001 <= num_part <= 9998:
                return b"\xb9\xdc\xc4\xda\xb8\xdf\xcb\xd9\xb6\xaf\xb3\xb5", GREEN
        elif class_tag == 'D':
            if 1 <= num_part <= 4998:
                return b"\xbf\xe7\xbe\xd6\xb6\xaf\xb3\xb5\xd7\xe9", WHITE
            elif 5001 <= num_part <= 9998:
                return b"\xb9\xdc\xc4\xda\xb6\xaf\xb3\xb5\xd7\xe9", WHITE
        elif class_tag == 'C':
            if 1 <= num_part <= 9998:
                return b"\xb3\xc7\xbc\xca\xb6\xaf\xb3\xb5\xd7\xe9", BLUE
        elif class_tag == 'S':
            if 1 <= num_part <= 9998:
                return b"\xca\xd0\xc7\xf8\xc1\xd0\xb3\xb5", BLUE
        elif class_tag == 'J':
            if 1 <= num_part <= 99998:
                return b"\xce\xb4\xc1\xd0\xbc\xec\xbc\xec\xb2\xe9\xc1\xd0\xb3\xb5", BLUE
        elif class_tag == 'Q':
            if 1 <= num_part <= 99998:
                return b"\xc7\xb0\xcf\xd6\xbe\xc8\xd4\xd6", RED
        elif class_tag == 'X':
            if 1 <= num_part <= 198:
                return b"\xd0\xd0\xd3\xca\xcc\xd8\xbf\xec\xc1\xd0\xb3\xb5", GREEN
            elif 201 <= num_part <= 998:
                return b"\xd0\xd0\xb0\xfc\xbf\xec\xcb\xd9\xc1\xd0\xb3\xb5", GREEN
            elif 8001 <= num_part <= 8998:
                return b"\xd6\xd0\xc5\xb7\xb0\xe0\xc1\xd0", GREEN
            elif 9001 <= num_part <= 9998:
                return b"\xd6\xd0\xc5\xb7\xd1\xc7\xc1\xaa\xd4\xcb", GREEN

        return b'\xce\xb4\xbb\xf1\xc8\xa1\xcd\xea\xd5\xfb\xca\xfd\xbe\xdd', RED

    if train_no and train_no != '---':
        tn = str(train_no).strip()
        tn = tn.replace('\r', '').replace('\n', '')
        if tn.isdigit() and len(tn) in [4, 5]:
            num = int(tn)
            if len(tn) == 4:
                if 1001 <= num <= 3998:
                    return b"\xd6\xb1\xcd\xa8\xc2\xc3\xbf\xcd\xc6\xd5\xbf\xec", GREEN
                elif 4001 <= num <= 5998:
                    return b"\xb9\xdc\xc4\xda\xc2\xc3\xbf\xcd\xc6\xd5\xbf\xec", GREEN
                elif 6001 <= num <= 6198:
                    return b"\xd6\xb1\xcd\xa8\xc2\xc3\xbf\xcd\xc2\xfd\xb3\xb5", WHITE
                elif 6201 <= num <= 7598:
                    return b"\xb9\xdc\xc4\xda\xc2\xc3\xbf\xcd\xc2\xfd\xb3\xb5", WHITE
                elif 7601 <= num <= 8998:
                    return b"\xcd\xa8\xc7\xda\xc1\xd0\xb3\xb5", YELLOW
                else:
                    return b'\xce\xb4\xd6\xaa', YELLOW
            elif len(tn) == 5:
                if tn.startswith('00'):
                    if 1 <= num <= 100:
                        return b"\xd3\xd0\xbb\xf0\xbb\xd8\xcb\xcd\xb6\xaf\xb3\xb5\xd7\xe9", RED
                    elif 101 <= num <= 198:
                        return b"\xbf\xe7\xbe\xd6\xce\xde\xbb\xf0\xbb\xd8\xcb\xcd", RED
                    elif 201 <= num <= 298:
                        return b"\xb9\xdc\xc4\xda\xce\xde\xbb\xf0\xbb\xd8\xcb\xcd", RED
                    elif 301 <= num <= 398:
                        return b"\xbf\xe7\xbe\xd6\xbb\xd8\xcb\xcd\xbf\xcd\xb3\xb5", YELLOW
                    elif 401 <= num <= 498:
                        return b"\xb9\xdc\xc4\xda\xbb\xd8\xcb\xcd\xbf\xcd\xb3\xb5", YELLOW

                for low, high, type_gbk, color in FREIGHT_TRAIN_RULES:
                    if low <= num <= high:
                        return type_gbk, color
                return b'\xce\xb4\xd6\xaa', YELLOW

    return b'\xce\xb4\xd6\xaa', RED


def encode_loco_gbk(loco):
    loco = str(loco)
    if loco.startswith("UNK("):
        return UNKNOWN_LOCO_GBK + loco[3:].encode()
    if loco.startswith("未知("):
        return UNKNOWN_LOCO_GBK + loco[2:].encode()

    separator = loco.find("-")
    name = loco if separator < 0 else loco[:separator]
    suffix = b"" if separator < 0 else loco[separator:].encode()
    name_gbk = LOCO_NAME_GBK.get(name)
    if name_gbk is not None:
        return name_gbk + suffix
    return loco.encode()


def get_serial_number():
    chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    try:
        n = int.from_bytes(machine.unique_id(), 'big')
        s = ""
        while n:
            n, r = divmod(n, 36)
            s = chars[r] + s
        s = s or "0"
        if len(s) < 12:
            s = ("0" * (12 - len(s))) + s
        return s[-12:]
    except Exception as e:
        print(e)
        return "S/N INVALID"


# 2. 系统全局变量
Serial_Number = get_serial_number()
MAX_HIST = 2000
HIST_FILE = "history.jsonl"
SD_LOG_FILE = "/sd/lbj_log.jsonl"
CONFIG_FILE = "config.json"
PPM_CALIBRATION_VERSION = 7

system_state = "DASHBOARD"
has_received = False
menu_index = 0

cfg_scr_idx = 3
SCR_OFF_OPTS = [
    b"30\xc3\xeb",
    b"1\xb7\xd6\xd6\xd3",
    b"5\xb7\xd6\xd6\xd3",
    b"\xb9\xd8\xb1\xd5\xcf\xa8\xc6\xc1",
    b"\xb0\xb4\xbc\xfc\xbf\xaa\xb9\xd8",
]
SCR_OFF_MS = [30000, 60000, 300000, -1, -1]
SCR_OFF_ON_DEMAND_INDEX = 4
cfg_buzzer = True
cfg_ppm_offset = 6.0
cfg_ppm_calibrated = False

menu_items = [
    b"\xb7\xe4\xc3\xf9\xc6\xf7: " + (b"\xbf\xaa" if cfg_buzzer else b"\xb9\xd8"),
    b"\xc9\xe8\xd6\xc3\xc8\xd5\xc6\xda",
    b"\xcc\xf8\xd7\xaa\xb5\xbd\xbc\xc7\xc2\xbc",
    b"\xb8\xf1\xca\xbd\xbb\xaf\xc9\xc1\xb4\xe6",
    b"\xb8\xf1\xca\xbd\xbb\xafSD\xbf\xa8",
    b"\xb9\xd2\xd4\xd8SD\xbf\xa8",
    b"\xb9\xd8\xd3\xda\xc9\xe8\xb1\xb8",
    b"\xcf\xa8\xc6\xc1\xca\xb1\xbc\xe4: " + SCR_OFF_OPTS[cfg_scr_idx],
]

hist_ptr = -1
total_count = 0

history_offsets = array.array('I')
last_interaction = time.ticks_ms()

last_minute = -1
last_sd_err_time = 0

sd_active = False
sd_obj = None
current_sd_status = "NO SD CARD"

edit_y, edit_m, edit_d = 24, 1, 1
edit_id = [0, 0, 0, 0]
edit_step = 0

current_status = b'READY'
current_status_color = GREEN

last_basic, last_ext = {}, {}
last_is_full = True

need_post_train_gc = False
last_screen_layout = None
buzzer_off_at = None


# 3. 核心功能函数
def beep():
    global buzzer_off_at
    if not cfg_buzzer:
        return
    buzzer.value(1)
    time.sleep_ms(BUTTON_BEEP_MS)
    buzzer.value(0)
    buzzer_off_at = None


def service_buzzer(now):
    global buzzer_off_at
    if buzzer_off_at is not None and time.ticks_diff(now, buzzer_off_at) >= 0:
        buzzer.value(0)
        buzzer_off_at = None


def stop_buzzer():
    global buzzer_off_at
    buzzer.value(0)
    buzzer_off_at = None


def navigation_beep():
    beep()


def get_max_days(y, m):
    if m == 2:
        return 29 if y % 4 == 0 else 28
    return 30 if m in [4, 6, 9, 11] else 31


def get_rtc_date_for_edit():
    try:
        year, month, day = rtc.get_date()
        if (24 <= year <= 99 and 1 <= month <= 12
                and 1 <= day <= get_max_days(year, month)):
            return year, month, day
    except:
        pass
    return 26, 1, 1


def get_battery_info():
    bat_en.value(0)
    time.sleep_ms(5)
    raw = bat_adc.read_u16()
    bat_en.value(1)
    raw_volts = (raw / 65535) * 3.3 * 2
    volts = raw_volts + BAT_OFFSET
    percent = int((volts - 3.4) / (4.2 - 3.4) * 100)
    return f"{volts:.1f}V", f"{max(0, min(100, percent))}%"


def set_screen_power(enabled):
    global screen_is_on
    screen_is_on = bool(enabled)
    pin_bl.value(0 if screen_is_on else 1)


def handle_screen_button_event(wake_event):
    if cfg_scr_idx == SCR_OFF_ON_DEMAND_INDEX:
        if wake_event:
            set_screen_power(not screen_is_on)
            print("SCREEN_POWER", "ON" if screen_is_on else "OFF")
            beep()
            return True
        return not screen_is_on
    if not screen_is_on:
        set_screen_power(True)
        beep()
        return True
    return False


def wake_screen_for_train():
    if not screen_is_on and cfg_scr_idx != SCR_OFF_ON_DEMAND_INDEX:
        set_screen_power(True)


def _read_config_dict():
    try:
        with open(CONFIG_FILE, 'r') as f:
            return json.loads(f.read())
    except:
        return {}


def load_config():
    global cfg_buzzer, cfg_scr_idx, cfg_ppm_offset, cfg_ppm_calibrated, menu_items
    try:
        config = _read_config_dict()
        cfg_buzzer = config.get("buzzer", True)
        try:
            loaded_scr_idx = int(config.get("scr_idx", 3))
        except (TypeError, ValueError):
            loaded_scr_idx = 3
        cfg_scr_idx = loaded_scr_idx if 0 <= loaded_scr_idx < len(SCR_OFF_OPTS) else 3
        ppm_value = float(config.get("ppm_offset", 6.0))
        ppm_valid = -25.0 <= ppm_value <= 25.0
        ppm_version_ok = config.get("ppm_calibration_version", 0) == PPM_CALIBRATION_VERSION
        cfg_ppm_calibrated = (
            bool(config.get("ppm_calibrated", False))
            and ppm_valid and ppm_version_ok
        )
        cfg_ppm_offset = ppm_value if cfg_ppm_calibrated else 6.0
        menu_items[0] = b"\xb7\xe4\xc3\xf9\xc6\xf7: " + (b"\xbf\xaa" if cfg_buzzer else b"\xb9\xd8")
        menu_items[7] = b"\xcf\xa8\xc6\xc1\xca\xb1\xbc\xe4: " + SCR_OFF_OPTS[cfg_scr_idx]
    except:
        cfg_ppm_offset = 6.0
        cfg_ppm_calibrated = False


def save_config():
    try:
        config = _read_config_dict()
        config["buzzer"] = cfg_buzzer
        config["scr_idx"] = cfg_scr_idx
        config["ppm_offset"] = cfg_ppm_offset
        config["ppm_calibrated"] = cfg_ppm_calibrated
        config["ppm_calibration_version"] = PPM_CALIBRATION_VERSION
        with open(CONFIG_FILE, 'w') as f:
            f.write(json.dumps(config))
    except:
        pass


def init_history():
    global total_count, history_offsets
    history_offsets = array.array('I')
    try:
        with open(HIST_FILE, 'r') as f:
            while True:
                offset = f.tell()
                line = f.readline()
                if not line:
                    break
                history_offsets.append(offset)
        total_count = len(history_offsets)
    except:
        total_count = 0
        history_offsets = array.array('I')


def save_history(data, received_at=None):
    global total_count, history_offsets
    if total_count >= MAX_HIST:
        return False
    try:
        t_str = received_at if received_at is not None else rtc.get_history_time_str()
        record = {"t": t_str, "d": data}
        json_str = json.dumps(record)
        with open(HIST_FILE, 'a') as f:
            f.seek(0, 2)
            offset = f.tell()
            f.write(json_str + '\n')
            history_offsets.append(offset)
        total_count += 1
        return True
    except Exception as exc:
        print("HISTORY_WRITE_ERR", repr(exc))
        return False


def queue_history(data):
    if total_count + len(history_queue) >= MAX_HIST:
        return False
    if len(history_queue) >= HISTORY_QUEUE_CAPACITY:
        return False
    history_queue.put((data, rtc.get_history_time_str()))
    return True


def service_history_storage(now):
    global last_storage_write
    if len(history_queue) == 0 and len(sd_log_queue) == 0:
        return
    if time.ticks_diff(now, receiver.last_word_time) < HISTORY_RADIO_QUIET_MS:
        return
    if len(receiver.raw_queue) != 0:
        return
    if time.ticks_diff(now, last_storage_write) < STORAGE_WRITE_GAP_MS:
        return

    data = history_queue.get()
    if data is not None:
        save_history(data[0], data[1])
        last_storage_write = now
        return

    data = sd_log_queue.get()
    if data is not None:
        log_to_sd(data)
        last_storage_write = now


def queue_sd_log(data):
    if not sd_active or len(sd_log_queue) >= HISTORY_QUEUE_CAPACITY:
        return False
    sd_log_queue.put(data)
    return True


def load_history_entry(idx):
    if idx < 0 or idx >= len(history_offsets):
        return None
    try:
        with open(HIST_FILE, 'r') as f:
            f.seek(history_offsets[idx])
            line = f.readline()
            return json.loads(line)
    except:
        return None


def check_sd_startup():
    global current_sd_status, sd_active, sd_obj, menu_items
    try:
        tft_cs.value(1)
        spi1.init(baudrate=1000000)
        sd_obj = sdcard.SDCard(spi1, sd_cs)
        os.mount(os.VfsFat(sd_obj), "/sd")
        s = os.statvfs("/sd")
        total_kb = (s[0] * s[2]) / 1024
        free_kb = (s[0] * s[3]) / 1024
        used_kb = total_kb - free_kb
        if total_kb > 1048576:
            current_sd_status = f"SD:{used_kb/1048576:.1f}/{total_kb/1048576:.1f}G"
        else:
            current_sd_status = f"SD:{used_kb/1024:.1f}/{total_kb/1024:.1f}M"
        sd_active = True
    except:
        sd_active = False
        sd_obj = None
        current_sd_status = "NO SD CARD"
    finally:
        menu_items[5] = b"\xb0\xce\xb3\xf6SD\xbf\xa8" if sd_active else b"\xb9\xd2\xd4\xd8SD\xbf\xa8"
        spi1.init(baudrate=TFT_SPI_BAUD, polarity=0, phase=0)


def disable_sd_forever(reason, redraw=True):
    global sd_active, current_sd_status, sd_obj, menu_items, last_sd_err_time
    try:
        os.umount("/sd")
    except:
        pass
    sd_active = False
    sd_obj = None
    current_sd_status = reason
    last_sd_err_time = time.ticks_ms()
    menu_items[5] = b"\xb9\xd2\xd4\xd8SD\xbf\xa8"
    if redraw:
        if system_state == "DASHBOARD":
            update_top_bar()
        elif system_state == "MENU":
            draw_menu(full=True)


def log_to_sd(data):
    if not sd_active:
        return
    redraw_after_error = False
    try:
        t_str = rtc.get_time_str(True)
        j_str = json.dumps({"t": t_str, "d": data}) + '\n'
        tft_cs.value(1)
        spi1.init(baudrate=5000000)
        with open(SD_LOG_FILE, 'a') as f:
            f.write(j_str)
    except Exception as exc:
        print("SD_LOG_ERR", repr(exc))
        disable_sd_forever("SD WRITE ERR", redraw=False)
        redraw_after_error = True
    finally:
        spi1.init(baudrate=TFT_SPI_BAUD, polarity=0, phase=0)
    if redraw_after_error:
        if system_state == "DASHBOARD":
            update_top_bar()
        elif system_state == "MENU":
            draw_menu(full=True)


# 4. UI 绘制函数
def draw_ui_skeleton():
    global last_screen_layout
    last_screen_layout = None
    safe_fill_rect(0, 0, 320, 240, BLACK)
    tft.fill_rect(0, 190, 320, 1, GRAY)
    tft.draw_gbk(b"BAT:", 5, 218, GRAY, BLACK)
    tft.draw_gbk(b"RSSI:", 120, 218, GRAY, BLACK)
    tft.draw_gbk(b"T:", 245, 218, GRAY, BLACK)
    update_top_bar()


def update_top_bar():
    global last_minute
    tft.fill_rect(0, 0, 320, 24, 0x01CF)
    tft.draw_gbk(current_sd_status.encode(), 10, 4, WHITE, 0x01CF)
    t_str = rtc.get_time_str(show_seconds=False)
    tft.draw_gbk(t_str.encode(), 145, 4, YELLOW, 0x01CF)
    try:
        last_minute = int(t_str.split(':')[1])
    except:
        pass
    tft.draw_gbk(current_status, 230, 4, current_status_color, 0x01CF)


def draw_hardware_bar(force=False):
    global last_hw_update, last_rssi_str, hist_rssi_str, system_state
    global last_battery_v, last_battery_p, last_temp_str, last_vbus_display
    now = time.ticks_ms()
    usb_powered = bool(vbus_sense.value())
    sample_due = (
        last_battery_v is None
        or time.ticks_diff(now, last_hw_update) >= 30000
    )
    if not force and not sample_due and usb_powered == last_vbus_display:
        return

    if sample_due:
        last_battery_v, last_battery_p = get_battery_info()
        try:
            reading = sensor_temp.read_u16() * (3.3 / 65535.0)
            temp_c = 27 - (reading - 0.706) / 0.001721
            last_temp_str = f"{temp_c:.1f}C"
        except Exception:
            last_temp_str = "ERR"
        last_hw_update = now

    v, p, t = last_battery_v, last_battery_p, last_temp_str
    r = hist_rssi_str if system_state == "HISTORY" else last_rssi_str

    raw_p = int(p.replace('%', ''))
    bat_color = RED if raw_p < 20 else WHITE

    tft.fill_rect(45, 218, 75, 16, BLACK)
    tft.draw_gbk(v.encode(), 45, 218, WHITE if usb_powered else bat_color, BLACK)
    tft.draw_gbk(b'CHRG' if usb_powered else p.encode(), 85, 218,
                 GREEN if usb_powered else bat_color, BLACK)
    last_vbus_display = usb_powered

    tft.fill_rect(170, 218, 70, 16, BLACK)
    tft.draw_gbk(r.encode(), 170, 218, WHITE, BLACK)

    tft.fill_rect(265, 218, 50, 16, BLACK)
    tft.draw_gbk(t.encode(), 265, 218, WHITE, BLACK)


def draw_idle_screen():
    global last_screen_layout
    last_screen_layout = None
    safe_fill_rect(0, 26, 320, 164, BLACK)
    tft.draw_gbk(b'\xd5\xfd\xd4\xda\xcb\xd1\xd1\xb0\xd0\xc5\xba\xc5\xc7\xeb\xc9\xd4\xb5\xc8', 15, 95, GRAY, BLACK, scale=2)


def draw_km_post(km, x, y, preferred_scale, row_height, bg_color, spaced=False):
    value = str(km)
    if (not spaced and preferred_scale == 2 and len(value) == 6
            and value[:4].isdigit() and value[4] == '.'
            and value[5].isdigit()):
        for index, char in enumerate(value):
            tft.draw_gbk(char.encode(), x + index * 14, y,
                         GREEN, bg_color, scale=2)
        tft.draw_gbk(b'K', x + 88, y + 16, GREEN, bg_color, scale=1)
        return
    label = (value + (' K' if spaced else 'K')).encode()
    scale = preferred_scale
    while scale > 1 and x + len(label) * 8 * scale > 320:
        scale -= 1
    tft.draw_gbk(label, x, y + (row_height - 16 * scale) // 2,
                 GREEN, bg_color, scale=scale)


def display_train_data(basic, ext, is_full_mode=True, is_history=False, hist_time="", hist_idx=0):
    global last_screen_layout

    current_layout = f"{'HIST' if is_history else 'DASH'}_{'FULL' if is_full_mode else 'BASIC'}"
    bg_color = 0x1082 if is_history else BLACK
    is_partial = (last_screen_layout == current_layout)

    if not is_partial:
        safe_fill_rect(0, 26, 320, 164, bg_color)

    if is_history:
        if is_partial:
            tft.fill_rect(0, 30, 320, 16, bg_color)
        header = f"HISTORY [{hist_idx+1}/{total_count}]  {format_history_time(hist_time)}"
        tft.draw_gbk(header.encode(), 5, 30, YELLOW, bg_color, scale=1)
        y_offset = 20
    else:
        y_offset = 0

    train_no = basic.get('train_no', '---')
    speed = str(basic.get('speed_kmh', '---'))
    km = str(basic.get('km_post', '---'))
    cls = ext.get('class_tag', '') if ext.get('class_tag') != '?' else ''
    full_train = f"{cls}{train_no}"
    if len(full_train) > 8:
        full_train = full_train[:8]

    if not is_full_mode:
        sc = 2 if is_history else 3
        y_start = 55 if is_history else 35
        y_step = 40 if is_history else 50
        lbl_w = 48 if sc == 2 else 72
        h = 16 * sc

        if not is_partial:
            tft.draw_gbk(b'\xb3\xb5:', 20, y_start, WHITE, bg_color, scale=sc)
            tft.draw_gbk(b'\xcb\xd9:', 20, y_start+y_step, WHITE, bg_color, scale=sc)
            tft.draw_gbk(b'\xb1\xea:', 20, y_start+y_step*2, WHITE, bg_color, scale=sc)
        else:
            tft.fill_rect(20+lbl_w, y_start, 300-lbl_w, h, bg_color)
            tft.fill_rect(20+lbl_w, y_start+y_step, 300-lbl_w, h, bg_color)
            tft.fill_rect(20+lbl_w, y_start+y_step*2, 300-lbl_w, h, bg_color)

        tft.draw_gbk(full_train.encode(), 20+lbl_w, y_start, CYAN, bg_color, scale=sc)
        tft.draw_gbk(speed.encode() + b' KM/H', 20+lbl_w, y_start+y_step, YELLOW, bg_color, scale=sc)
        tft.draw_gbk(km.encode() + b' K', 20+lbl_w, y_start+y_step*2, GREEN, bg_color, scale=sc)

    else:
        y1 = 27 + y_offset
        y2 = 62 + y_offset
        y3 = 97 + y_offset
        y4 = 132 + y_offset

        loco = ext.get('loco_type', '----')
        loco_raw = ext.get('loco_raw', '')
        cab = ext.get('cab_end', '')
        if cab == '31':
            loco += 'A'
        elif cab == '32':
            loco += 'B'
        if loco_raw and len(loco_raw) >= 8:
            type_code = loco_raw[:3]
            special_types = ['344', '361', '400', '401', '411', '413', '422', '403', '415']
            if type_code in special_types:
                loco_number = loco_raw[3:8]
                loco_name = loco.split('-')[0] if '-' in loco else loco
                loco = f"{loco_name}-{loco_number}"

        SS_MODELS = ['SS1', 'DF4D', 'SS3', 'SS4', 'SS5', 'SS6', 'SS7', 'SS8', 'SS9',
                     'SS3B', 'SS3C', 'SS4G', 'SS6B', 'SS7B', 'SS7C', 'SS7D', 'SS7E',
                     'DF11', 'DF11G', 'DF8B', 'DF4B', 'DF8']
        if not is_history and loco and loco != '----':
            for model in SS_MODELS:
                if loco.startswith(model):
                    buzzer.value(1)
                    time.sleep_ms(100)
                    buzzer.value(0)
                    time.sleep_ms(50)
                    buzzer.value(1)
                    time.sleep_ms(100)
                    buzzer.value(0)
                    break

        class_tag = ext.get('class_tag', '')
        train_type_gbk, type_color = get_train_type(train_no, class_tag)

        if not is_partial:
            tft.draw_gbk(b'\xb3\xb5:', 5, y1, WHITE, bg_color, scale=2)
            tft.draw_gbk(b'\xcb\xd9:', 170, y1, WHITE, bg_color, scale=2)
            tft.draw_gbk(b'\xcf\xdf:', 5, y2, WHITE, bg_color, scale=2)
            tft.draw_gbk(b'\xbb\xfa:', 5, y3, WHITE, bg_color, scale=2)
            tft.draw_gbk(b'\xc0\xe0:', 5, y4, WHITE, bg_color, scale=2)
        else:
            tft.fill_rect(53, y1, 115, 32, bg_color)
            tft.fill_rect(218, y1, 102, 32, bg_color)
            tft.fill_rect(53, y2, 127, 32, bg_color)
            tft.fill_rect(180, y2, 140, 32, bg_color)
            tft.fill_rect(53, y3, 267, 32, bg_color)
            tft.fill_rect(53, y4, 267, 32, bg_color)

        tft.draw_gbk(full_train.encode(), 53, y1, CYAN, bg_color, scale=2)
        tft.draw_gbk(speed.encode() + b'KM/H', 218, y1, YELLOW, bg_color, scale=2)

        route_hex = ext.get('route_hex', '')
        route_b = bytes.fromhex(route_hex)[:8] if route_hex else b'----'
        tft.draw_gbk(route_b, 53, y2, WHITE, bg_color, scale=2)

        digits = [c for c in str(train_no) if c.isdigit()]
        direction = b'\xc9\xcf' if digits and int(digits[-1]) % 2 == 0 else b'\xcf\xc2'
        tft.draw_gbk(direction, 180, y2, MAGENTA, bg_color, scale=2)
        draw_km_post(km, 220, y2, 2, 32, bg_color)

        loco_display = encode_loco_gbk(loco)
        tft.draw_gbk(loco_display, 53, y3, WHITE, bg_color, scale=2)

        if train_type_gbk and train_type_gbk != b'\xce\xb4\xd6\xaa':
            tft.draw_gbk(train_type_gbk, 53, y4, type_color, bg_color, scale=2)
        else:
            tft.draw_gbk(b'\xb5\xa5\xbb\xfa\xbf\xaa\xc6\xf4LBJ', 53, y4, WHITE, bg_color, scale=2)

    lon = str(ext.get('lon') or '---').replace('°', ' ')
    lat = str(ext.get('lat') or '---').replace('°', ' ')
    tft.fill_rect(0, 192, 320, 18, BLACK)
    tft.draw_gbk(b'GPS: ' + lon.encode() + b' / ' + lat.encode(), 5, 195, GRAY, BLACK, scale=1)

    last_screen_layout = current_layout


def draw_menu(full=True, old_idx=-1):
    global last_screen_layout
    if full:
        last_screen_layout = None
        safe_fill_rect(0, 26, 320, 164, 0x2104)
        tft.draw_gbk(b'--- \xcf\xb5\xcd\xb3\xc9\xe8\xd6\xc3 ---', 80, 40, CYAN, 0x2104)
        for i in range(len(menu_items)):
            draw_menu_item(i, i == menu_index)
    else:
        if old_idx >= 0:
            draw_menu_item(old_idx, False)
        draw_menu_item(menu_index, True)


def draw_menu_item(i, is_selected):
    color = YELLOW if is_selected else WHITE
    prefix = b'> ' if is_selected else b'  '
    tft.fill_rect(40, 60 + i*16, 240, 16, 0x2104)
    tft.draw_gbk(prefix + menu_items[i], 40, 60 + i*16, color, 0x2104)


def draw_set_date(full=True):
    global last_screen_layout
    if full:
        last_screen_layout = None
        safe_fill_rect(0, 26, 320, 164, 0x2104)
        tft.draw_gbk(b'---\xc9\xe8\xd6\xc3\xc8\xd5\xc6\xda---', 95, 40, CYAN, 0x2104)
        tft.draw_gbk(b'-', 134, 90, WHITE, 0x2104, scale=2)
        tft.draw_gbk(b'-', 182, 90, WHITE, 0x2104, scale=2)
        tft.draw_gbk(b'[UP/DOWN]\xb5\xf7\xd5\xfb  [OK]\xc8\xb7\xc8\xcf', 20, 155, GRAY, 0x2104, scale=1)

    cols = [YELLOW if edit_step == i else WHITE for i in range(3)]

    tft.fill_rect(70, 90, 64, 32, 0x2104)
    tft.fill_rect(150, 90, 32, 32, 0x2104)
    tft.fill_rect(198, 90, 32, 32, 0x2104)

    tft.draw_gbk(f"20{edit_y:02}".encode(), 70, 90, cols[0], 0x2104, scale=2)
    tft.draw_gbk(f"{edit_m:02}".encode(), 150, 90, cols[1], 0x2104, scale=2)
    tft.draw_gbk(f"{edit_d:02}".encode(), 198, 90, cols[2], 0x2104, scale=2)


def draw_jump_id(full=True):
    global last_screen_layout
    if full:
        last_screen_layout = None
        safe_fill_rect(0, 26, 320, 164, 0x2104)
        tft.draw_gbk(b'--- \xcc\xf8\xd7\xaa\xb5\xbd ---', 85, 40, CYAN, 0x2104)
        tft.draw_gbk(b'RANGE: 0001 -', 60, 75, GRAY, 0x2104)
        tft.draw_gbk(str(total_count).encode(), 170, 75, GREEN, 0x2104)

    for i in range(4):
        color = YELLOW if edit_step == i else WHITE
        tft.fill_rect(110 + i*25, 110, 16, 32, 0x2104)
        tft.draw_gbk(str(edit_id[i]).encode(), 110 + i*25, 110, color, 0x2104, scale=2)


def draw_confirm_format():
    global last_screen_layout
    last_screen_layout = None
    safe_fill_rect(0, 26, 320, 164, 0x5000)
    tft.draw_gbk(b'!!! \xbe\xaf\xb8\xe6 !!!', 35, 50, WHITE, 0x5000, scale=2)
    tft.draw_gbk(b'\xc9\xbe\xb3\xfd\xb0\xe5\xd4\xd8\xcb\xf9\xd3\xd0\xca\xfd\xbe\xdd?', 60, 90, YELLOW, 0x5000)
    tft.draw_gbk(b'[OK] \xc8\xb7\xb6\xa8  [MENU] \xc8\xa1\xcf\xfb', 30, 140, WHITE, 0x5000)


def draw_confirm_format_sd():
    global last_screen_layout
    last_screen_layout = None
    safe_fill_rect(0, 26, 320, 164, 0x5000)
    tft.draw_gbk(b'!!!\xc4\xda\xb4\xe6\xbf\xa8\xbe\xaf\xb8\xe6!!!', 15, 50, WHITE, 0x5000, scale=2)
    tft.draw_gbk(b'\xc9\xbe\xb3\xfd\xc4\xda\xb4\xe6\xbf\xa8\xcb\xf9\xd3\xd0\xca\xfd\xbe\xdd?', 65, 90, YELLOW, 0x5000)
    tft.draw_gbk(b'[OK] \xc8\xb7\xb6\xa8  [MENU] \xc8\xa1\xcf\xfb', 15, 140, WHITE, 0x5000)


def draw_about():
    global last_screen_layout
    last_screen_layout = None
    safe_fill_rect(0, 26, 320, 164, 0x2104)
    tft.draw_gbk(b'---  \xb9\xd8\xd3\xda\xc9\xe8\xb1\xb8 ---', 75, 40, CYAN, 0x2104)
    es_tag = " (ES)" if is_es_ver == 1 else " (Rel)"
    tft.draw_gbk(f"Version: v{Program_ver}{es_tag}".encode(), 40, 70, RED if is_es_ver == 1 else WHITE, 0x2104)
    tft.draw_gbk(f"Records : {total_count}/{MAX_HIST}".encode(), 40, 95, WHITE, 0x2104)
    tft.draw_gbk(b"Author: " + Author_Name.encode(), 40, 120, YELLOW, 0x2104)
    tft.draw_gbk(b"S/N number: " + Serial_Number.encode(), 40, 145, WHITE, 0x2104)
    tft.draw_gbk(b'\xb0\xb4\xcf\xc2\xbc\xfc\xb7\xb5\xbb\xd8', 40, 175, GRAY, 0x2104)


def draw_popup(msg, color=RED):
    tft.fill_rect(60, 80, 200, 60, color)
    tft.draw_gbk(msg, 75, 100, WHITE, color)


# 5. 核心 1 子线程
def light_callback(data, queue=ui_queue, lock=ui_lock):
    msg_type = data.get("type", "")
    if msg_type == "error":
        print("RADIO_EVENT_ERR", data.get("error", "unknown"))
        return
    if msg_type != "time_sync" and "train_data" not in msg_type and "only" not in msg_type:
        return
    with lock:
        queue.put(data)


def radio_core_task(receiver_obj, state=radio_state,
                    auto_recovery=RADIO_AUTO_RECOVERY_ENABLED,
                    recovery_threshold=RADIO_ERROR_RECOVERY_THRESHOLD):
    import time
    while True:
        try:
            receiver_obj.tick()
            state[1] = 0
        except Exception as exc:
            state[2] = (state[2] + 1) & 0x3FFFFFFF
            state[1] += 1
            now = time.ticks_ms()
            if time.ticks_diff(now, state[3]) >= 2000:
                try:
                    print("RADIO_TICK_ERR", "count=", state[2], repr(exc))
                except Exception:
                    pass
                state[3] = now
            if auto_recovery and state[1] >= recovery_threshold:
                try:
                    if receiver_obj.recover(
                        "tick_exception",
                        hard=(state[1] >= recovery_threshold * 2),
                    ):
                        state[1] = 0
                except Exception as recovery_exc:
                    try:
                        print("RADIO_RECOVERY_ERR", repr(recovery_exc))
                    except Exception:
                        pass
        state[0] = time.ticks_ms()
        time.sleep_ms(1)


def process_ui_data(data):
    global last_basic, last_ext, last_is_full, has_received, current_status, current_status_color, last_rssi_str
    global screen_is_on, last_interaction, need_post_train_gc

    try:
        msg_type = data.get("type", "")
        if msg_type == "time_sync":
            hh, mm = map(int, data.get('time').split(':'))
            if hh == 0 and mm == 0:
                print("TIME_SYNC_SKIP midnight")
                return
            if 0 <= hh < 24 and 0 <= mm < 60:
                rtc.sync_time(hh, mm)
                if system_state == "DASHBOARD":
                    current_status, current_status_color = b'TIME SYNC', YELLOW
                    update_top_bar()
        elif "train_data" in msg_type or "only" in msg_type:
            beep()
            has_received = True
            wake_screen_for_train()
            last_interaction = time.ticks_ms()

            if "rssi" in data:
                last_rssi_str = str(data["rssi"])

            queue_history(data)
            queue_sd_log(data)
            service_buzzer(time.ticks_ms())

            last_basic, last_ext = data.get("basic", {}), data.get("extended", {})
            last_is_full = (msg_type != "basic_only")

            if system_state == "DASHBOARD":
                if total_count + len(history_queue) >= MAX_HIST:
                    current_status, current_status_color = b'MEM FULL', RED
                else:
                    current_status, current_status_color = (b'FULL DATA', GREEN) if last_is_full else (b'BASIC', YELLOW)

                current_status = current_status[:8]
                update_top_bar()
                display_train_data(last_basic, last_ext, last_is_full)
                draw_hardware_bar(force=True)

            need_post_train_gc = True
    except Exception as exc:
        print("UI_EVENT_ERR", msg_type, repr(exc))


# 6. 启动初始化
load_config()
post = SystemPOST(tft, tft_cs)
boot_status = post.run_all(bat_adc, bat_en, sensor_temp, rtc, spi1, sd_cs, buzzer, Program_ver, is_es_ver)
spi1.init(baudrate=TFT_SPI_BAUD, polarity=0, phase=0)
if boot_status == "HALT":
    while True:
        pass

init_history()
check_sd_startup()

receiver = LBJReceiver(ppm_offset=cfg_ppm_offset)
receiver.set_callback(light_callback)
radio_state[RADIO_HEARTBEAT] = time.ticks_ms()
last_radio_health_log = radio_state[RADIO_HEARTBEAT]
_thread.start_new_thread(radio_core_task, (receiver,))

if boot_status == "RTC_SYNC":
    system_state = "SET_DATE"
    edit_step = 0
    edit_y, edit_m, edit_d = get_rtc_date_for_edit()
    draw_ui_skeleton()
    draw_set_date(full=True)
else:
    draw_ui_skeleton()
    draw_idle_screen()
    draw_hardware_bar(force=True)

menu_button = ButtonTracker(btn_menu)
up_button = ButtonTracker(btn_up, repeat=True)
down_button = ButtonTracker(btn_down, repeat=True)
ok_button = ButtonTracker(btn_ok)
wake_button = ButtonTracker(btn_wake)
last_sec = time.ticks_ms()
heartbeat = False

# 7. 核心 0 主循环
while True:
    now = time.ticks_ms()
    service_buzzer(now)

    if time.ticks_diff(now, radio_state[RADIO_HEARTBEAT]) > RADIO_CORE_STALL_MS:
        if time.ticks_diff(now, radio_state[RADIO_LAST_ERROR_LOG]) >= 5000:
            print("RADIO_CORE_STALL", "age_ms=", time.ticks_diff(now, radio_state[RADIO_HEARTBEAT]))
            radio_state[RADIO_LAST_ERROR_LOG] = now

    if time.ticks_diff(now, last_radio_health_log) >= RADIO_HEALTH_LOG_MS:
        with ui_lock:
            ui_pending = len(ui_queue)
            ui_dropped = ui_queue.dropped
        print("RADIO_HEALTH", receiver.get_health_snapshot(),
              "thread_errors=", radio_state[RADIO_TOTAL_ERRORS],
              "ui_pending=", ui_pending,
              "ui_dropped=", ui_dropped,
              "history_pending=", len(history_queue),
              "sd_pending=", len(sd_log_queue),
              "mem_free=", gc.mem_free())
        last_radio_health_log = now

    screen_timeout_ms = SCR_OFF_MS[cfg_scr_idx]
    if screen_is_on and screen_timeout_ms >= 0:
        if time.ticks_diff(now, last_interaction) > screen_timeout_ms:
            set_screen_power(False)

    if need_post_train_gc and time.ticks_diff(now, last_interaction) > 1000:
        gc.collect()
        need_post_train_gc = False

    ui_data_to_process = None
    with ui_lock:
        ui_data_to_process = ui_queue.get()

    if ui_data_to_process:
        try:
            process_ui_data(ui_data_to_process)
        except Exception as exc:
            print("UI_QUEUE_ERR", repr(exc))

    try:
        service_history_storage(now)
    except Exception as exc:
        print("STORAGE_SERVICE_ERR", repr(exc))
        history_queue.clear()
        sd_log_queue.clear()

    if gc.mem_free() < 20000:
        gc.collect()

    if time.ticks_diff(now, last_sec) > 1000:
        if system_state == "DASHBOARD":
            heartbeat = not heartbeat
            tft.fill_rect(310, 8, 6, 6, GREEN if heartbeat else 0x01CF)
            t_str = rtc.get_time_str(show_seconds=False)
            try:
                now_min = int(t_str.split(':')[1])
                if now_min != last_minute:
                    tft.fill_rect(135, 4, 60, 16, 0x01CF)
                    tft.draw_gbk(t_str.encode(), 135, 4, YELLOW, 0x01CF)
                    last_minute = now_min
            except:
                pass

            if not sd_active and current_sd_status != "NO SD CARD" and time.ticks_diff(now, last_sd_err_time) > 3000:
                current_sd_status = "NO SD CARD"
                update_top_bar()

        if screen_is_on and system_state in ("DASHBOARD", "HISTORY"):
            draw_hardware_bar(force=False)
        last_sec = now

    if system_state == "HISTORY" and time.ticks_diff(now, last_interaction) > 20000:
        system_state = "DASHBOARD"
        draw_ui_skeleton()
        draw_hardware_bar(force=True)
        last_interaction = now
        if has_received:
            display_train_data(last_basic, last_ext, last_is_full)
        else:
            draw_idle_screen()

    wake_event = wake_button.poll(now)
    menu_event = menu_button.poll(now)
    down_event = down_button.poll(now)
    up_event = up_button.poll(now)
    ok_event = ok_button.poll(now)
    any_button_event = wake_event or menu_event or down_event or up_event or ok_event

    if any_button_event:
        last_interaction = now
        if handle_screen_button_event(wake_event):
            continue

    if wake_event:
        beep()

    if menu_event:
        last_interaction = now
        beep()
        if system_state in ["DASHBOARD", "HISTORY", "ABOUT", "CONFIRM_FORMAT", "CONFIRM_FORMAT_SD", "SET_DATE", "JUMP_ID"]:
            system_state = "MENU"
            draw_menu(full=True)
        else:
            system_state = "DASHBOARD"
            draw_ui_skeleton()
            draw_hardware_bar(force=True)
            if has_received:
                display_train_data(last_basic, last_ext, last_is_full)
            else:
                draw_idle_screen()

    if down_event:
        last_interaction = now
        navigation_beep()
        if system_state == "DASHBOARD" and total_count > 0:
            system_state = "HISTORY"
            hist_ptr = total_count - 1
            entry = load_history_entry(hist_ptr)
            if entry:
                hist_rssi_str = str(entry['d'].get('rssi', 'N/A'))
                display_train_data(entry['d'].get('basic', {}), entry['d'].get('extended', {}),
                                   entry['d'].get('type') != "basic_only", True, entry['t'], hist_ptr)
                draw_hardware_bar(force=True)
        elif system_state == "HISTORY":
            hist_ptr = (hist_ptr - 1) % total_count
            entry = load_history_entry(hist_ptr)
            if entry:
                hist_rssi_str = str(entry['d'].get('rssi', 'N/A'))
                display_train_data(entry['d'].get('basic', {}), entry['d'].get('extended', {}),
                                   entry['d'].get('type') != "basic_only", True, entry['t'], hist_ptr)
                draw_hardware_bar(force=True)
        elif system_state == "MENU":
            old_idx = menu_index
            menu_index = (menu_index - 1) % len(menu_items)
            draw_menu(full=False, old_idx=old_idx)
        elif system_state == "SET_DATE":
            if edit_step == 0:
                edit_y = (edit_y + 1) % 100
                edit_d = min(edit_d, get_max_days(edit_y, edit_m))
            elif edit_step == 1:
                edit_m = edit_m % 12 + 1
                edit_d = min(edit_d, get_max_days(edit_y, edit_m))
            else:
                edit_d = (edit_d % get_max_days(edit_y, edit_m)) + 1
            draw_set_date(full=False)
        elif system_state == "JUMP_ID":
            edit_id[edit_step] = (edit_id[edit_step] + 1) % 10
            draw_jump_id(full=False)

    if up_event:
        last_interaction = now
        navigation_beep()
        if system_state == "DASHBOARD" and total_count > 0:
            system_state = "HISTORY"
            hist_ptr = total_count - 1
            entry = load_history_entry(hist_ptr)
            if entry:
                hist_rssi_str = str(entry['d'].get('rssi', 'N/A'))
                display_train_data(entry['d'].get('basic', {}), entry['d'].get('extended', {}),
                                   entry['d'].get('type') != "basic_only", True, entry['t'], hist_ptr)
                draw_hardware_bar(force=True)
        elif system_state == "HISTORY":
            hist_ptr = (hist_ptr + 1) % total_count
            entry = load_history_entry(hist_ptr)
            if entry:
                hist_rssi_str = str(entry['d'].get('rssi', 'N/A'))
                display_train_data(entry['d'].get('basic', {}), entry['d'].get('extended', {}),
                                   entry['d'].get('type') != "basic_only", True, entry['t'], hist_ptr)
                draw_hardware_bar(force=True)
        elif system_state == "MENU":
            old_idx = menu_index
            menu_index = (menu_index + 1) % len(menu_items)
            draw_menu(full=False, old_idx=old_idx)
        elif system_state == "SET_DATE":
            if edit_step == 0:
                edit_y = (edit_y - 1) % 100
                edit_d = min(edit_d, get_max_days(edit_y, edit_m))
            elif edit_step == 1:
                edit_m = edit_m - 1 if edit_m > 1 else 12
                edit_d = min(edit_d, get_max_days(edit_y, edit_m))
            else:
                edit_d = edit_d - 1 if edit_d > 1 else get_max_days(edit_y, edit_m)
            draw_set_date(full=False)
        elif system_state == "JUMP_ID":
            edit_id[edit_step] = (edit_id[edit_step] - 1) % 10
            draw_jump_id(full=False)

    if ok_event:
        last_interaction = now
        beep()
        if system_state == "HISTORY" or system_state == "ABOUT":
            system_state = "DASHBOARD"
            draw_ui_skeleton()
            draw_hardware_bar(force=True)
            if has_received:
                display_train_data(last_basic, last_ext, last_is_full)
            else:
                draw_idle_screen()

        elif system_state == "MENU":
            if menu_index == 0:
                cfg_buzzer = not cfg_buzzer
                menu_items[0] = b"\xb7\xe4\xc3\xf9\xc6\xf7: " + (b"\xbf\xaa" if cfg_buzzer else b"\xb9\xd8")
                save_config()
                draw_menu_item(0, True)
            elif menu_index == 1:
                edit_y, edit_m, edit_d = get_rtc_date_for_edit()
                edit_step = 0
                system_state = "SET_DATE"
                draw_set_date(full=True)
            elif menu_index == 2:
                edit_step = 0
                edit_id = [0, 0, 0, 0]
                system_state = "JUMP_ID"
                draw_jump_id(full=True)
            elif menu_index == 3:
                system_state = "CONFIRM_FORMAT"
                draw_confirm_format()
            elif menu_index == 4:
                if not sd_active:
                    draw_popup(b'NO SD CARD!', color=RED)
                    stop_buzzer()
                    time.sleep(1)
                    draw_menu(full=True)
                else:
                    system_state = "CONFIRM_FORMAT_SD"
                    draw_confirm_format_sd()
            elif menu_index == 5:
                if sd_active:
                    draw_popup(b'UNMOUNTING...', color=YELLOW)
                    disable_sd_forever("SD REMOVED")
                    draw_popup(b'SAFE TO REMOVE', color=CYAN)
                    stop_buzzer()
                    time.sleep(2)
                else:
                    draw_popup(b'MOUNTING SD...', color=YELLOW)
                    check_sd_startup()
                    service_buzzer(time.ticks_ms())
                    if sd_active:
                        draw_popup(b'MOUNT OK!', color=GREEN)
                    else:
                        draw_popup(b'MOUNT FAIL!', color=RED)
                system_state = "DASHBOARD"
                draw_ui_skeleton()
                draw_hardware_bar(force=True)
                if has_received:
                    display_train_data(last_basic, last_ext, last_is_full)
                else:
                    draw_idle_screen()
            elif menu_index == 6:
                system_state = "ABOUT"
                draw_about()
            elif menu_index == 7:
                cfg_scr_idx = (cfg_scr_idx + 1) % len(SCR_OFF_OPTS)
                menu_items[7] = b"\xcf\xa8\xc6\xc1\xca\xb1\xbc\xe4: " + SCR_OFF_OPTS[cfg_scr_idx]
                save_config()
                draw_menu_item(7, True)

        elif system_state == "SET_DATE":
            edit_step += 1
            if edit_step > 2:
                rtc.set_date(edit_y, edit_m, edit_d)
                system_state = "MENU"
                draw_menu(full=True)
            else:
                draw_set_date(full=False)

        elif system_state == "JUMP_ID":
            edit_step += 1
            if edit_step > 3:
                target_id = edit_id[0]*1000 + edit_id[1]*100 + edit_id[2]*10 + edit_id[3] - 1
                if 0 <= target_id < total_count:
                    system_state = "HISTORY"
                    hist_ptr = target_id
                    entry = load_history_entry(hist_ptr)
                    hist_rssi_str = str(entry['d'].get('rssi', 'N/A'))
                    display_train_data(entry['d'].get('basic', {}), entry['d'].get('extended', {}),
                                       entry['d'].get('type') != "basic_only", True, entry['t'], hist_ptr)
                    draw_hardware_bar(force=True)
                else:
                    draw_popup(b'INDEX ERROR!')
                    stop_buzzer()
                    time.sleep(1)
                    draw_jump_id(full=True)
                    edit_step = 0
            else:
                draw_jump_id(full=False)

        elif system_state == "CONFIRM_FORMAT":
            draw_popup(b'FORMATTING...', color=GREEN)
            history_queue.clear()
            sd_log_queue.clear()
            with ui_lock:
                ui_queue.clear()
            open(HIST_FILE, 'w').close()
            total_count = 0
            hist_ptr = -1
            history_offsets = array.array('I')
            has_received = False
            last_basic = {}
            last_ext = {}
            last_is_full = True
            current_status = b'READY'
            current_status_color = GREEN
            need_post_train_gc = False
            stop_buzzer()
            time.sleep(1)
            system_state = "DASHBOARD"
            draw_ui_skeleton()
            draw_idle_screen()
            draw_hardware_bar(force=True)

        elif system_state == "CONFIRM_FORMAT_SD":
            draw_popup(b'FORMATTING SD...', color=YELLOW)
            stop_buzzer()
            try:
                if 'sd' in os.listdir('/'):
                    try:
                        os.umount("/sd")
                    except:
                        pass
                tft_cs.value(1)
                spi1.init(baudrate=1000000)
                sd_obj = sdcard.SDCard(spi1, sd_cs)
                spi1.init(baudrate=10000000)
                os.VfsFat.mkfs(sd_obj)
                os.mount(os.VfsFat(sd_obj), "/sd")
                draw_popup(b'SD FORMAT OK!', color=GREEN)
            except:
                sd_obj = None
                draw_popup(b'FORMAT FAIL!', color=RED)
                disable_sd_forever("FORMAT FAIL")
            spi1.init(baudrate=TFT_SPI_BAUD, polarity=0, phase=0)
            time.sleep(1)
            system_state = "DASHBOARD"
            draw_ui_skeleton()
            draw_idle_screen()
            draw_hardware_bar(force=True)

    time.sleep_ms(1)